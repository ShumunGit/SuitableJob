import firebase from 'firebase/compat/app';
import 'firebase/compat/auth';
import 'firebase/compat/firestore';
import 'firebase/compat/storage';

// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
    apiKey: "AIzaSyB9fkJXi7RLoQ32QTKuxv5nN4TcivoJ5_c",
    authDomain: "suitable-job-upload-image.firebaseapp.com",
    projectId: "suitable-job-upload-image",
    storageBucket: "suitable-job-upload-image.appspot.com",
    messagingSenderId: "597442492301",
    appId: "1:597442492301:web:a4e66857029909a72e6fc4",
    measurementId: "G-7F7CTCVW4N"
};

firebase.initializeApp(firebaseConfig)

const mystorage = firebase.storage();

export { mystorage, firebase as default};