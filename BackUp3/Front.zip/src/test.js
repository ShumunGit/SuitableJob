/*
// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyB9fkJXi7RLoQ32QTKuxv5nN4TcivoJ5_c",
  authDomain: "suitable-job-upload-image.firebaseapp.com",
  projectId: "suitable-job-upload-image",
  storageBucket: "suitable-job-upload-image.appspot.com",
  messagingSenderId: "597442492301",
  appId: "1:597442492301:web:0c932319d295edfa2e6fc4",
  measurementId: "G-9Y169XQKJJ"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);*/

//------------------------------------------------------------------
<Form action="http://localhost:2021/Login" method="post">
  <Form.Group className="mb-3" controlId="formBasicEmail">
    <Form.Label>Email address</Form.Label>
    <Form.Control type="email" name="email" placeholder="Enter email" />
    <Form.Text className="text-muted">
      We'll never share your email with anyone else.
    </Form.Text>
  </Form.Group>

  <Form.Group className="mb-3" controlId="formBasicPassword">
    <Form.Label>Password</Form.Label>
    <Form.Control type="password" name="password" placeholder="Password" />
  </Form.Group>
  <Form.Group className="mb-3" controlId="formBasicCheckbox">
    <Form.Check type="checkbox" label="Save Login" />
  </Form.Group>
  <Button variant="primary" type="submit" /*onClick={() => { navigate('/Profile')}}*/>
    Submit
  </Button>
</Form>

import React, { useState, useRef, useEffect } from "react";
import { Button, Form } from "react-bootstrap";
import { useNavigate } from 'react-router-dom';
import axios from "axios";
import '../App.css';

function LogIn() {
  const url = "http://localhost:2021/Login";

  //let navigate = useNavigate();

  return (

    <div className="LoginForm">

      <Form>
        <Form.Group className="mb-3" controlId="formBasicEmail">
          <Form.Label>Email address</Form.Label>
          <Form.Control type="email" name="email" placeholder="Enter email" />
          <Form.Text className="text-muted">
            We'll never share your email with anyone else.
          </Form.Text>
        </Form.Group>

        <Form.Group className="mb-3" controlId="formBasicPassword">
          <Form.Label>Password</Form.Label>
          <Form.Control type="password" name="password" placeholder="Password" />
        </Form.Group>
        <Form.Group className="mb-3" controlId="formBasicCheckbox">
          <Form.Check type="checkbox" label="Save Login" />
        </Form.Group>
        <Button variant="primary" type="submit" /*onClick={() => { navigate('/Profile')}}*/>
          Submit
        </Button>
      </Form>


    </div>
  )
}

export default LogIn;

//---------------------------------------------------------------------------------------------
<div className="Navbarheader">
  <Navbar bg="myGreen" variant="dark" sticky='top' expand="lg">
    <LinkContainer to="Home">
      <Navbar.Brand>
        <img src={logo} width="40px" height="40px" class="rounded" alt="logo" />{' '}
        Suitable Job
      </Navbar.Brand>
    </LinkContainer>
    <Navbar.Toggle />
    <Navbar.Collapse>

      <Nav>
        <NavDropdown title="Suitable">
          <LinkContainer to='SuitableJob'>
            <NavDropdown.Item>Suitable Job</NavDropdown.Item>
          </LinkContainer>

          <NavDropdown.Item href='#'>Suitable Result</NavDropdown.Item>
          <NavDropdown.Item href='#'>Hours</NavDropdown.Item>
          <LinkContainer to="Profile">
            <NavDropdown.Item href='#'>Profile</NavDropdown.Item>
          </LinkContainer>

          <NavDropdown.Divider />
          <NavDropdown.Item href='#'>Instructions</NavDropdown.Item>
        </NavDropdown>

        <LinkContainer to='Contact'>
          <Nav.Link href='products'>Contact Us</Nav.Link>
        </LinkContainer>

        <LinkContainer to='Register'>
          <Nav.Link>Register</Nav.Link>
        </LinkContainer>

        <LinkContainer to='/Login'>
          <Nav.Link>Log in</Nav.Link>
        </LinkContainer>
      </Nav>

    </Navbar.Collapse>
  </Navbar>

</div>

{/*  <div class="container-fluid">
                            <div class="row">
                                <div class="col-sm-4 bg-success">
                                    <img height="auto" width="100%" src={url || "http://via.placeholder.com/300x300"} alt="" />
                        
                                </div>
                                <div class="col-sm-8 bg-warning">
                                    <Card style={{ width: '100%' }}>
                                        <Card.Body>
                                            <Card.Title>{Fname || "John"} {Lname || "Dow"}</Card.Title>
                                            <Card.Subtitle className="mb-2 text-muted">{title}</Card.Subtitle>
                                            <Card.Subtitle className="mb-2 text-muted">{phone}</Card.Subtitle>
                                            <Card.Subtitle className="mb-2 text-muted">{email}</Card.Subtitle>
                                            <Card.Subtitle className="mb-2 text-muted">{heighSchool.name}</Card.Subtitle>
                                            <Card.Subtitle className="mb-2 text-muted">{heighSchool.proffession}</Card.Subtitle>
                                            <Card.Text>
                                                {about || "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla a elit ac dolor pretium consectetur sed at orci. Fusce quam diam, finibus eget condimentum a, venenatis sit amet mauris. Etiam vitae eros volutpat, suscipit mauris vel, rutrum nunc. Nullam eu arcu nibh. Nunc semper massa condimentum tristique condimentum. Sed auctor molestie volutpat. Donec ac massa odio. Aliquam tristique sapien a quam volutpat vestibulum. Etiam sodales, felis eu blandit dignissim, est dui iaculis nisi, non maximus lacus lorem et arcu. Proin pharetra massa vitae arcu mattis cursus. Nullam vel elit non libero lacinia accumsan. Pellentesque mollis quam bibendum sagittis fermentum. Vestibulum vel leo turpis."}
                                            </Card.Text>

                                            <Card.Link target="_blank" href="https://github.com/ShumunGit">GitHub</Card.Link>
                                            <Card.Link target="_blank" href="https://www.linkedin.com/in/shimon-coen/">Linkedin</Card.Link>
                                            <Card.Link target="_blank" href="https://www.facebook.com">Facebook</Card.Link>

                                        </Card.Body>
                                    </Card>
                                </div>
                            </div>
                     </div>*/}