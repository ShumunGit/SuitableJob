import './App.css';
import 'bootstrap/dist/css/bootstrap.css'
import LogIn from './Components/Login';
import Register from './Components/Register';
import Contact from './Components/Contact';
import SuitableJob from './Components/Suitable';
import Footer from './Components/Footer';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import MainNav from './Components/NavMenu';
import Profile from './Components/Profile';
import Home from './Components/Home';
import CustomersPost from './Components/Result';
import LoginTest from './Components/LoginTest';
function App() {

  return (

    <Router>
      <div className="App">
        
        <MainNav />

        <Routes>
          <Route path='/Home' exact element={<Home />} />
          <Route path='/Login' element={<LogIn />} />
          <Route path='/Register' element={<Register />} />
          <Route path='/Contact' element={<Contact />} />
          <Route path='/Result' element={<CustomersPost />} />
          <Route path='/SuitableJob' element={<SuitableJob />} />
          <Route path='/Profile' element={<Profile />} />
        </Routes>

        <Footer />

      </div>
    </Router>

  );
}

export default App;
