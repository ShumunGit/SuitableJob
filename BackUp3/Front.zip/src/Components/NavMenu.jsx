import React from "react";
import 'bootstrap/dist/css/bootstrap.css'
import { Button, FormControl, Form, Container, Nav, Navbar, NavDropdown } from 'react-bootstrap';
import logo from '../img/logo.png';
import { LinkContainer } from 'react-router-bootstrap';

function MainNav() {
    return (
        <div className="Navbarheader">
            <Navbar collapseOnSelect expand="lg" bg="dark" variant="dark">
                <Container fluid>

                    <LinkContainer to='Home'>
                        <Navbar.Brand>
                            <img src={logo} width="40px" height="40px" class="img-fluid rounded" alt="logo" />
                        </Navbar.Brand></LinkContainer>

                    <Navbar.Brand href="SuitableJob">Suitable Search</Navbar.Brand>
                    
                    <Navbar.Toggle aria-controls="responsive-navbar-nav" />
                    <Navbar.Collapse id="responsive-navbar-nav">
                        <Nav className="me-auto">
                            <Nav.Link href="result">Suitables</Nav.Link>
                            <Nav.Link href="Home">Instructions</Nav.Link>
                            <NavDropdown title="MyProfile" id="collasible-nav-dropdown">
                                <NavDropdown.Item href="Profile">Profile Info</NavDropdown.Item>
                                <NavDropdown.Item href="#action/3.2">My Search</NavDropdown.Item>
                                <NavDropdown.Item href="#action/3.3">My Result</NavDropdown.Item>
                                <NavDropdown.Divider />
                                <NavDropdown.Item href="contact">Conntact</NavDropdown.Item>
                            </NavDropdown>
                        </Nav>
                        <Nav>
                            <Nav.Link href="register">Register</Nav.Link>
                            <Nav.Link eventKey={2} href="Login">
                                Log in 
                            </Nav.Link>
                        </Nav>
                    </Navbar.Collapse>
                </Container>
            </Navbar>

          
          {/* <Navbar bg="myGreen" expand="lg">
                <Container fluid>
                    <LinkContainer to='Home'>
                        <Navbar.Brand>
                            <img src={logo} width="40px" height="40px" class="img-fluid rounded" alt="logo" />
                        </Navbar.Brand></LinkContainer>
                    <Navbar.Toggle aria-controls="navbarScroll" />

                    <Navbar.Collapse id="navbarScroll">

                        <Nav
                            className="me-auto my-2 my-lg-0"
                            style={{ maxHeight: '100px' }}
                            navbarScroll
                        >
                            <LinkContainer to='SuitableJob'>
                                <Nav.Link>Suitable Search</Nav.Link></LinkContainer>

                            <LinkContainer to='Result'>
                                <Nav.Link>
                                    Result
                                </Nav.Link></LinkContainer>

                            <LinkContainer to="Profile">
                                <Nav.Link href="#">
                                    Profile
                                </Nav.Link></LinkContainer>
                            <LinkContainer to='Home'>
                                <Nav.Link href="#">
                                    Instructions
                                </Nav.Link></LinkContainer>

                            <LinkContainer to='Contact'>
                                <Nav.Link href='products'>Contact Us</Nav.Link>
                            </LinkContainer>

                        </Nav>
                        <Form className="d-flex justify-content-end">
                            <LinkContainer to='Register'>
                                <Nav.Link>Register</Nav.Link>
                            </LinkContainer>

                            <LinkContainer to='/Login'>
                                <Nav.Link>Log in</Nav.Link>
                            </LinkContainer>
                        </Form>

                    </Navbar.Collapse>
                </Container>
    </Navbar>*/}
            {/*  <Navbar bg="myGreen" variant="dark" sticky='top' expand="lg">
                <LinkContainer to="Home">
                    <Navbar.Brand>
                        <img src={logo} width="40px" height="40px" class="rounded" alt="logo" />{' '}
                        Suitable Job
                    </Navbar.Brand>
                </LinkContainer>
                <Navbar.Toggle />
                <Navbar.Collapse>

                    <Nav>
                        <NavDropdown title="Suitable">
                            <LinkContainer to='SuitableJob'>
                                <NavDropdown.Item>Suitable Job</NavDropdown.Item>
                            </LinkContainer>
    
                            <NavDropdown.Item href='#'>Suitable Result</NavDropdown.Item>
                            <NavDropdown.Item href='#'>Hours</NavDropdown.Item>
                            <LinkContainer to="Profile">
                                <NavDropdown.Item href='#'>Profile</NavDropdown.Item>
                            </LinkContainer>
                        
                            <NavDropdown.Divider />
                            <NavDropdown.Item href='#'>Instructions</NavDropdown.Item>
                        </NavDropdown>

                        <LinkContainer to='Contact'>
                            <Nav.Link href='products'>Contact Us</Nav.Link>
                        </LinkContainer>

                            <LinkContainer to='Register'>
                                <Nav.Link>Register</Nav.Link>
                            </LinkContainer>

                            <LinkContainer to='/Login'>
                                <Nav.Link>Log in</Nav.Link>
                            </LinkContainer>
                    </Nav>

                </Navbar.Collapse>
            </Navbar>*/}

        </div>
    )
}

export default MainNav;