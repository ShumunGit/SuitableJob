import React, { useEffect, useState } from "react";
import axios from "axios";
import { Card } from 'react-bootstrap'
function UserCardInfo(props){
    const [user, setUser] = useState(null);

    const url = 'http://localhost:2021/UserData-Info'

    useEffect(() => {
        axios.get(url).then(res => {
            console.log(res.data)
            //setUser(res.data)
        })
    }, [])

    return(
        <div className="Profile-Info">
            <Card id="my-image" >
                <Card.Img variant="top" src={props.card}/>
                <Card.Body>
                    <Card.Title>{props.Fname}</Card.Title>
                    <Card.Title as="h6">{props.Email}</Card.Title>
                    <Card.Title as="h6">{props.Phone}</Card.Title>
                    <Card.Text>
                      {props.About}
                    </Card.Text>
                </Card.Body>
                <Card.Footer>
                    <small className="text-muted">{props.Title}</small>
                </Card.Footer>
            </Card>
        </div>
    )
}

export default UserCardInfo;