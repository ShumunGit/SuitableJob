import React from "react";
import { Button, Form, Row, Col } from "react-bootstrap";
import '../App.css';
import { useNavigate } from 'react-router-dom';
function Contact() {
    const navigate = useNavigate();
    return (
        <div className="ContactForm">
            <Form action="http://localhost:2021/Contact" method="post" target="_blank">

                <Row className="mb-3">
                    <Form.Group as={Col} controlId="formGridFname">
                        <Form.Label>First Name</Form.Label>
                        <Form.Control type="text" name="fname" placeholder="Enter First name" />
                    </Form.Group>

                    <Form.Group as={Col} controlId="formGridLname">
                        <Form.Label>Last Name</Form.Label>
                        <Form.Control type="text" name="lname" placeholder="Enter Last Name" />
                    </Form.Group>
                </Row>

                <Row className="mb-3">
                    <Form.Group as={Col} controlId="formGridEmail">
                        <Form.Label>Email</Form.Label>
                        <Form.Control type="email" name="email" placeholder="Enter email" />
                    </Form.Group>

                    <Form.Group as={Col} controlId="formGridPhone">
                        <Form.Label>Phone</Form.Label>
                        <Form.Control type="phone" name="phone" placeholder="Enter Phone" />
                    </Form.Group>
                </Row>

                <Row className="mb-3">
                    <Form.Group as={Col} controlId="formGridSubject">
                        <Form.Label>Subject</Form.Label>
                        <Form.Control type="text" name="subject" placeholder="Enter Subject" />

                        <Form.Group as={Col} controlId="formGridSubject">
                            <label for="validationTextarea"></label>
                            <textarea class="form-control" name="textarea" rows="7" placeholder="Write Text" required></textarea>
                        </Form.Group>
                    </Form.Group>
            
                </Row>

                <Button /*onClick={()=>{navigate('/Home')}}*/ variant="primary" type="submit">
                    Submit
                </Button>
            </Form>
        </div>
    )
}

export default Contact;