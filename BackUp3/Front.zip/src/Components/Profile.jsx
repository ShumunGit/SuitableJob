import React, { useEffect } from "react";
import { ListGroupItem, ListGroup, Card, Accordion, Button, Form, Row, Col } from "react-bootstrap";
import { useState } from "react";
import { mystorage } from "../firebase";
import UserCardInfo from "./UserCard";
import '../App.css';

function Profile(props) {
    // url for images. 
    const [image, setImage] = useState(null);
    const [url, setUrl] = useState("");

    // Details. 
    const [Fname, setFname] = useState("");
    const [Lname, setLname] = useState("");
    const [title, setTitle] = useState("");
    const [about, setAbout] = useState("");
    const [phone, setPhone] = useState("");
    const [email, setEmail] = useState("");

    // address.
    const [country, setCountry] = useState("");
    const [city, setCity] = useState("");
    const [address, setAddress] = useState("");

    // Education.
    const [heighSchool, setHeighschool] = useState("");
    const [HsProfession, setHsprofession] = useState("");

    const [education, setEducation] = useState("");
    const [Eduprofession, setEduprofession] = useState("");

    const [otherSchool, setOtherSchhol] = useState("");
    const [otherProfession, setOtherProfession] = useState("");

    // Exprience. 
    const [firstExp, setFirstExp] = useState("");
    const [firstProfession, setFirstProfession] = useState("");
    const [fStart, setFstart] = useState("");
    const [fEnd, setFend] = useState("");

    const [secExp, setSecExp] = useState("");
    const [secProfession, setSecProfession] = useState("");
    const [secStart, setSecStart] = useState("");
    const [secEnd, setSecEnd] = useState("");

    const [thirdExp, setThirdExp] = useState("");
    const [thirdPro, setThirdPro] = useState("");
    const [thirdStart, setThirdStart] = useState("");
    const [thirdEnd, setThirdEnd] = useState("");

    const handleChange = e => {
        if (e.target.files[0]) {
            setImage(e.target.files[0])
        }
    }

    const handleUpload = () => {
        const uploadTask = mystorage.ref(`images/${image.name}`).put(image);
        uploadTask.on(
            "state_change",
            snapshot => { },
            error => {
                console.log(error);
            },
            () => {
                mystorage
                    .ref("images")
                    .child(image.name)
                    .getDownloadURL()
                    .then(myurl => {
                        setUrl(myurl);
                    })
            }
        )
    };


    useEffect(() => {
        const getImgUrl = window.localStorage.getItem("my-Picture");
        setUrl(JSON.parse(getImgUrl));

        const getF_name = window.localStorage.getItem("F_name");
        setFname(JSON.parse(getF_name));
        const getL_name = window.localStorage.getItem("L_name")
        setLname(JSON.parse(getL_name));

        const get_title = window.localStorage.getItem("title")
        setTitle(JSON.parse(get_title))

        const get_About = window.localStorage.getItem("about")
        setAbout(JSON.parse(get_About))

        const get_Phone = window.localStorage.getItem("phone")
        setPhone(JSON.parse(get_Phone))

        const get_Email = window.localStorage.getItem("email")
        setEmail(JSON.parse(get_Email));

        const get_Country = window.localStorage.getItem("country")
        setCountry(JSON.parse(get_Country))

        const get_city = window.localStorage.getItem("city")
        setCity(JSON.parse(get_city))

        const get_address = window.localStorage.getItem("address")
        setAddress(JSON.parse(get_address))

        const get_heighschoolname = window.localStorage.getItem("Hegihschool")
        setHeighschool(JSON.parse(get_heighschoolname))
        const get_Hsprofession = window.localStorage.getItem("Hsprofession")
        setHsprofession(JSON.parse(get_Hsprofession))

        const get_educatoin = window.localStorage.getItem("education")
        setEducation(JSON.parse(get_educatoin))
        const get_Eduprofession = window.localStorage.getItem("Eduprofession")
        setEduprofession(JSON.parse(get_Eduprofession))

        const get_otherSchool = window.localStorage.getItem("otherSchool")
        setOtherSchhol(JSON.parse(get_otherSchool))
        const get_otherProfession = window.localStorage.getItem("otherProfession")
        setOtherProfession(JSON.parse(get_otherProfession))

        const get_firstExp = window.localStorage.getItem("firstExp")
        setFirstExp(JSON.parse(get_firstExp));
        const get_firstPro = window.localStorage.getItem("firstProfession")
        setFirstProfession(JSON.parse(get_firstPro));

        {/* const get_firstDate = window.localStorage.getItem("fStart")
        const get_EndDate = window.localStorage.Item("fEnd")
        setFend(JSON.parse(get_EndDate))
        setFstart(JSON.parse(get_firstDate));*/}

        const get_SecExp = window.localStorage.getItem("secExp")
        setSecExp(JSON.parse(get_SecExp))
        const get_SecProfession = window.localStorage.getItem("secProfession")
        setSecProfession(JSON.parse(get_SecProfession))

        const get_thirdExp = window.localStorage.getItem("thirdExp")
        setThirdExp(JSON.parse(get_thirdExp))
        const get_thirdPro = window.localStorage.getItem("thirdPro")
        setThirdPro(JSON.parse(get_thirdPro))


    }, [])

    //console.log("Image result: ", setImage);

    useEffect(() => {
        window.localStorage.setItem('my-Picture', JSON.stringify(url))
        window.localStorage.setItem('F_name', JSON.stringify(Fname))
        window.localStorage.setItem('L_name', JSON.stringify(Lname))
        window.localStorage.setItem('title', JSON.stringify(title))
        window.localStorage.setItem('about', JSON.stringify(about))
        window.localStorage.setItem('phone', JSON.stringify(phone))
        window.localStorage.setItem('email', JSON.stringify(email))
        window.localStorage.setItem('country', JSON.stringify(country))
        window.localStorage.setItem('city', JSON.stringify(city))
        window.localStorage.setItem('address', JSON.stringify(address))
        window.localStorage.setItem('Hegihschool', JSON.stringify(heighSchool))
        window.localStorage.setItem('Hsprofession', JSON.stringify(HsProfession))
        window.localStorage.setItem('education', JSON.stringify(education))
        window.localStorage.setItem('Eduprofession', JSON.stringify(Eduprofession))
        window.localStorage.setItem('otherSchool', JSON.stringify(otherSchool))
        window.localStorage.setItem('otherProfession', JSON.stringify(otherProfession))

        window.localStorage.setItem('firstExp', JSON.stringify(firstExp))
        window.localStorage.setItem('firstProfession', JSON.stringify(firstProfession))
        window.localStorage.setItem('fStart', JSON.stringify(fStart))
        window.localStorage.setItem('fEnd', JSON.stringify(fEnd))

        window.localStorage.setItem('secExp', JSON.stringify(secExp))
        window.localStorage.setItem('secProfession', JSON.stringify(secProfession))

        window.localStorage.setItem('thirdExp', JSON.stringify(thirdExp))
        window.localStorage.setItem('thirdPro', JSON.stringify(thirdPro))

    })

    return (
        <div className="ProfileForm">
            <Accordion defaultActiveKey="0" alwaysOpen>

                {/* About me */}
                <Accordion.Item eventKey="0">

                    <Accordion.Header>About Me</Accordion.Header>
                    <Accordion.Body>
                        <UserCardInfo card={url} Fname={Fname+ " " + Lname} 
                                      About={about}  Title={title} Phone={phone} Email={email}/>
                    </Accordion.Body>
                </Accordion.Item>

                {/*Api address*/}
                <Form action="http://localhost:2021/UserDetails" method="post">

                    {/* Details */}
                    <Accordion.Item eventKey="1">
                        <Accordion.Header>Details</Accordion.Header>
                        <Accordion.Body>


                            {/* my info */}
                            <Row className="mb-3">
                                <Form.Group as={Col} controlId="formGridName">
                                    <Form.Label>First Name</Form.Label>
                                    <Form.Control name="Fname" onChange={(e) => setFname(e.target.value)} type="text" placeholder={Fname || "Enter Fist name"} />
                                </Form.Group>

                                <Form.Group as={Col} controlId="formGridLname">
                                    <Form.Label>Last Name</Form.Label>
                                    <Form.Control name="Lname" onChange={(e) => setLname(e.target.value)} type="text" placeholder={Lname || "Enter Last name"} />
                                </Form.Group>

                                <Form.Group as={Col} controlId="formGridCountry">
                                    <Form.Label>Phone</Form.Label>
                                    <Form.Control name="Phone" onChange={(e) => setPhone(e.target.value)} type="text" placeholder={phone || "Enter your phone"} />
                                </Form.Group>

                                <Form.Group as={Col} controlId="formGridCity">
                                    <Form.Label>Email</Form.Label>
                                    <Form.Control name="UserEmail" onChange={(e) => setEmail(e.target.value)} type="text" placeholder={email || "Enter your email"} />
                                </Form.Group>

                                <Form.Group as={Col} controlId="formGridTitle">
                                    <Form.Label>Title</Form.Label>
                                    <Form.Control name="UserTitle" onChange={(e) => setTitle(e.target.value)} type="text" placeholder={title || "Enter Title"} />
                                </Form.Group>

                            </Row>

                            {/* Addres*/}
                            <Row className="mb-3">
                                <Form.Group as={Col} controlId="formGridCountry">
                                    <Form.Label>Country</Form.Label>
                                    <Form.Control name="country" onChange={(e) => setCountry(e.target.value)} type="text" placeholder={country || "Enter your country"} />
                                </Form.Group>

                                <Form.Group as={Col} controlId="formGridCity">
                                    <Form.Label>City</Form.Label>
                                    <Form.Control name="city" onChange={(e) => setCity(e.target.value)} type="text" placeholder={city || "Enter your city"} />
                                </Form.Group>

                                <Form.Group as={Col} controlId="formGridAddress">
                                    <Form.Label>Address</Form.Label>
                                    <Form.Control name="address" onChange={(e) => setAddress(e.target.value)} type="text" placeholder={address || "Enter you Address"} />
                                </Form.Group>
                            </Row>

                            {/* about me. */}
                            <Row className="mb-3">
                                <Form.Group className="mb-3" controlId="exampleForm.ControlTextarea1">
                                    <Form.Label>About </Form.Label>
                                    <Form.Control name="about" onChange={(e) => setAbout(e.target.value)} placeholder={about || "About you in 5 rows"} as="textarea" rows={3} />
                                </Form.Group>
                            </Row>

                            {/* upload image */}
                            <Row className="mb-3">
                                <Form.Group as={Col} controlId="formGridCity">
                                    <Form.Label>Choose File</Form.Label>
                                    <Form.Control onChange={handleChange} type="file" placeholder="" />
                                    <br></br>
                                    <Button variant="primary" type="button" value="Upload image" onClick={handleUpload}>Upload Iamge</Button>
                                </Form.Group>
                            </Row>

                        </Accordion.Body>
                    </Accordion.Item>

                    {/* Education */}
                    <Accordion.Item eventKey="2">
                        <Accordion.Header>Education</Accordion.Header>
                        <Accordion.Body>

                            {/* heigh school */}
                            <Row className="mb-3">
                                <Form.Group as={Col} controlId="formGridName">
                                    <Form.Label>Heigh School</Form.Label>
                                    <Form.Control name="HeighSchoolName" onChange={(e) => setHeighschool(e.target.value)} type="text" placeholder={heighSchool || "Enter your heigh School name"} />
                                </Form.Group>

                                <Form.Group as={Col} controlId="formGridLname">
                                    <Form.Label>Profession</Form.Label>
                                    <Form.Control name="HeighSchoolProfession" onChange={(e) => setHsprofession(e.target.value)} type="text" placeholder={HsProfession || "enter graduation"} />
                                </Form.Group>
                            </Row>

                            {/* Heigh education*/}
                            <Row className="mb-3">
                                <Form.Group as={Col} controlId="formGridName">
                                    <Form.Label>Heigh Edication</Form.Label>
                                    <Form.Control name="HeighEduName" onChange={(e) => setEducation(e.target.value)} type="text" placeholder={education || "Enter Universities name"} />
                                </Form.Group>

                                <Form.Group as={Col} controlId="formGridLname">
                                    <Form.Label>Profession</Form.Label>
                                    <Form.Control name="EduProfession" onChange={(e) => setEduprofession(e.target.value)} type="text" placeholder={Eduprofession || "enter your profession"} />
                                </Form.Group>
                            </Row>

                            {/* other education */}
                            <Row className="mb-3">
                                <Form.Group as={Col} controlId="formGridName">
                                    <Form.Label>Other Edication</Form.Label>
                                    <Form.Control name="OtherEduName" onChange={(e) => setOtherSchhol(e.target.value)} type="text" placeholder={otherSchool || "enter other universitie"} />
                                </Form.Group>

                                <Form.Group as={Col} controlId="formGridLname">
                                    <Form.Label>Profession</Form.Label>
                                    <Form.Control name="OtherProfession" onChange={(e) => setOtherProfession(e.target.value)} type="text" placeholder={otherProfession || "enter your profession"} />
                                </Form.Group>
                            </Row>

                        </Accordion.Body>
                    </Accordion.Item>

                    {/* Experience */}
                    <Accordion.Item eventKey="3">
                        <Accordion.Header>Experience</Accordion.Header>
                        <Accordion.Body>

                            {/* my last job */}
                            <Row className="mb-3">
                                <Form.Group as={Col} controlId="formGridName">
                                    <Form.Label>Last Job</Form.Label>
                                    <Form.Control name="First_job" onChange={(e) => setFirstExp(e.target.value)} type="text" placeholder={firstExp || "Company name"} />
                                </Form.Group>

                                <Form.Group as={Col} controlId="formGridLname">
                                    <Form.Label>Profession</Form.Label>
                                    <Form.Control name="First_pro" onChange={(e) => setFirstProfession(e.target.value)} type="text" placeholder={firstProfession || "profession"} />
                                </Form.Group>

                                <Form.Group as={Col} controlId="formGridName">
                                    <Form.Label>Start</Form.Label>
                                    <input name="First_start" onChange={(e) => setFstart(e.target.value)} type="date" class="form-control" id="entry_date" value={fStart || "2012-12-12"} />
                                </Form.Group>

                                <Form.Group as={Col} controlId="formGridLname">
                                    <Form.Label>End</Form.Label>
                                    <input name="First_end" onChange={(e) => setFend(e.target.value)} type="date" class="form-control" id="entry_date" value={fEnd || "2012-12-12"} />
                                </Form.Group>

                            </Row>

                            {/* my second last job */}
                            <Row className="mb-3">
                                <Form.Group as={Col} controlId="formGridName">
                                    <Form.Label>Last Job</Form.Label>
                                    <Form.Control name="Sec_job" onChange={(e) => setSecExp(e.target.value)} type="text" placeholder={secExp || "Company name"} />
                                </Form.Group>

                                <Form.Group as={Col} controlId="formGridLname">
                                    <Form.Label>Profession</Form.Label>
                                    <Form.Control name="Sec_pro" onChange={(e) => setSecProfession(e.target.value)} type="text" placeholder={secProfession || "profession"} />
                                </Form.Group>

                                <Form.Group as={Col} controlId="formGridName">
                                    <Form.Label>Start</Form.Label>
                                    <input name="Sec_start" onChange={(e) => setSecStart(e.target.value)} type="date" class="form-control" id="entry_date" placeholder={secStart || "2022-12-12"} />
                                </Form.Group>

                                <Form.Group as={Col} controlId="formGridLname">
                                    <Form.Label>End</Form.Label>
                                    <input name="Sec_end" onChange={(e) => setSecEnd(e.target.value)} type="date" class="form-control" id="entry_date" placeholder={secEnd || "2022-10-12"} />
                                </Form.Group>

                            </Row>

                            {/* my third last job */}
                            <Row className="mb-3">
                                <Form.Group as={Col} controlId="formGridName">
                                    <Form.Label>Last Job</Form.Label>
                                    <Form.Control name="Third_job" onChange={(e) => setThirdExp(e.target.value)} type="text" placeholder={thirdExp || "Company name"} />
                                </Form.Group>

                                <Form.Group as={Col} controlId="formGridLname">
                                    <Form.Label>Profession</Form.Label>
                                    <Form.Control name="Third_pro" onChange={(e) => setThirdPro(e.target.value)} type="text" placeholder={thirdPro || "profession"} />
                                </Form.Group>

                                <Form.Group as={Col} controlId="formGridStart">
                                    <Form.Label>Start</Form.Label>
                                    <input name="Third_start" onChange={(e) => setThirdStart(e.target.value)} type="date" class="form-control" id="entry_date" placeholder={thirdStart || "2022-10-01"} />
                                </Form.Group>

                                <Form.Group as={Col} controlId="formGridEnd">
                                    <Form.Label>End</Form.Label>
                                    <input name="Third_end" onChange={(e) => setThirdEnd(e.target.value)} type="date" class="form-control" id="entry_date" placeholder={thirdEnd || "2022-05-02"} />
                                </Form.Group>

                            </Row>

                            <Button variant="primary" type="submit">
                                Submit
                            </Button>

                        </Accordion.Body>
                    </Accordion.Item>

                </Form>
            </Accordion>
        </div>

    )
}

export default Profile;