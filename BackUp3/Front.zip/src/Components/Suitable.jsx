import React from "react";
import { Button, Form, Row, Col } from "react-bootstrap";
import '../App.css';
import axios from 'axios';

function SuitableJob() {

    {/*
    const options = {
        method: 'GET',
        url: 'https://indeed-job-posting-software.p.rapidapi.com/jobposts/fullstack',
        headers: {
            'X-RapidAPI-Host': 'indeed-job-posting-software.p.rapidapi.com',
            'X-RapidAPI-Key': '5244d31626msh133f1dfa08dbf81p1efa3djsn328adc51a7f3'
        }
    };

    axios.request(options).then(function (response) {
        console.log(response.data[2]);
    }).catch(function (error) {
        console.error(error);
    });*/}


    return (
        <div className="SuitableForm">

            <Form>
                <Row className="mb-3">
                    <Form.Group as={Col} controlId="formGridCity">
                        <Form.Label>City</Form.Label>
                        <Form.Control type="text" placeholder="enter city" />
                    </Form.Group>

                    <Form.Group as={Col} controlId="formGridState">
                        <Form.Label>Type of work</Form.Label>
                        <Form.Select defaultValue="Choose...">
                            <option>Full - Time </option>
                            <option>Part - Time</option>
                        </Form.Select>
                    </Form.Group>

                    <Form.Group as={Col} controlId="formGridfield">
                        <Form.Label>Salart</Form.Label>
                        <Form.Control type="text" placeholder="Offer salary" />
                    </Form.Group>

                    <Form.Group as={Col} controlId="formGridProfession">
                        <Form.Label>Job Title</Form.Label>
                        <Form.Control type="text" placeholder="enter job Title" />
                    </Form.Group>
                </Row>

                <Row className="mb-3">
                    <Form.Group as={Col} controlId="formGridAvailble">
                        <Form.Check type="checkbox" label="Availble" />
                    </Form.Group>
                    <Form.Group as={Col} controlId="formGridExprience">
                        <Form.Check type="checkbox" label="Exprience" />
                    </Form.Group>
                    <Form.Group as={Col} controlId="formGridSave">
                        <Form.Check type="checkbox" label="Save" />
                    </Form.Group>
                    <Form.Group as={Col} controlId="formGridbutton">
                        <Button variant="primary" type="submit">
                            Submit
                        </Button>
                    </Form.Group>

                </Row>


            </Form>
        </div>

    )
}

export default SuitableJob;