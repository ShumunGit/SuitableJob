import React, { useState } from "react";
import PersonList from "./PostLst";
import '../App.css';
function CustomersPost(){
    
    return(
        <div className="Result">
            <PersonList />
        </div>
    )
}

export default CustomersPost;