import React from "react";
import '../App.css';
import { Button, Form, Row, Col } from "react-bootstrap";
//import { useNavigate } from 'react-router-dom';
function Register() {

    //const navigate = useNavigate();

    return (
        <div className="RegisterForm">
            <Form action="http://localhost:2021/CustomerRegister" method="post" /*target={navigate("./Home.jsx")}*/ >

                <Row className="mb-3">
                    <Form.Group as={Col} controlId="formGridFname">
                        <Form.Label>First Name</Form.Label>
                        <Form.Control type="text" name="Fname"  placeholder="Enter First name" />
                    </Form.Group>

                    <Form.Group as={Col} controlId="formGridLname">
                        <Form.Label>Last Name</Form.Label>
                        <Form.Control type="text" name="Lname" placeholder="Enter Last Name" />
                    </Form.Group>
                </Row>

                <Row className="mb-3">
                    <Form.Group as={Col} controlId="formGridEmail">
                        <Form.Label>Email</Form.Label>
                        <Form.Control type="email" name="email" placeholder="Enter email" />
                    </Form.Group>

                    <Form.Group as={Col} controlId="formGridPhone">
                        <Form.Label>Phone</Form.Label>
                        <Form.Control type="phone" name="phone" placeholder="Enter Phone" />
                    </Form.Group>
                </Row>

                <Form.Group className="mb-3" controlId="formGridPassword">
                    <Form.Label>Password</Form.Label>
                    <Form.Control type="password" name="password" placeholder="Password" />
                </Form.Group>

                <Form.Group className="mb-3" controlId="formGridConfirmPass">
                    <Form.Label>Confirm Password</Form.Label>
                    <Form.Control type="password" name="cpassword" placeholder="Password" />
                </Form.Group>
         
                <Button variant="primary" type="submit">
                    Submit
                </Button>
            </Form>
        </div>

    )
}

export default Register;