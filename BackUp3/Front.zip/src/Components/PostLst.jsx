import React from "react";
import axios from "axios";
import { Button, Form, Row, Col, ListGroup, Card } from "react-bootstrap";
import { useEffect } from "react";

export default class PersonList extends React.Component {
    state = {
        persons: []
    }

    componentDidMount() {
        axios.get('http://localhost:2021/JobsList').then(res => {
            //console.log(res.data)
            const persons = res.data;
            this.setState({ persons });
        })
    }

    render() {
        const { persons } = this.state;
        return (
            <div className="LiPosts">

                        <Row xs={1} md={1} className="g-4">
                            {Array.from({ length: persons.length }).map((_,idx) => (
                                <Col key={idx}>
                                    <Card>
                                        <Card.Header>{persons[idx].City}, {persons[idx].JobTitle}</Card.Header>
                                        <Card.Body>
                                            <Card.Title>Salary: {persons[idx].Salary}</Card.Title>
                                            <Card.Title>{persons[idx].TypeOfWork}</Card.Title>

                                            <Card.Text>
                                                {persons[idx].SuitableDescription}
                                            </Card.Text>
                                            <Card.Text>{persons[idx].requirements}</Card.Text>
                                        </Card.Body>

                                        <Card.Footer>Contact: {persons[idx].Email}</Card.Footer>
                                    </Card>
                                </Col>
                            ))}
                        </Row>
            
               {/* <table id="customers">
                      <thead id="theadTable">
                 
                    </thead>
                    <tbody id="tbodyTable">
                        {
                            this.state.persons.map(persons =>
                                <tr key={persons.id} class="list-group-item">
                                    <td> <b>City: </b> 	&nbsp; {persons.City} </td> 
                                    <td> <b>Type of work: </b> &nbsp;{persons.TypeOfWork} </td>
                                    <td> <b>Salary: </b> &nbsp; {persons.Salary} </td>
                                    <td> <b>Title: </b> &nbsp;{persons.JobTitle} </td>
                                    <td> <b>Contact: </b> &nbsp;{persons.Email} </td>
                                    <br />
                                    <p><b>Description</b></p>
                                    <td> {persons.SuitableDescription} </td>
                                    <br />
                                    <p><b>Reuirements</b></p>
                                    <td> {persons.requirements} </td>
                                </tr>
                            )
                        }
                    </tbody>
                    </table>*/}
                {/*<ul class="list-group">
                    {
                        this.state.persons.map(persons =>
                            <li key={persons.id} class="list-group-item">City: {persons.City}  | TypeOfWork: {persons.TypeOfWork} | Contact: {persons.Email}</li>
                        )
                    }
                </ul>*/}
            </div>

        )
    }
}