import React, { useState } from "react";
import '../App.css';
import axios from "axios";
import { Button, Form, Row, Col, Card } from "react-bootstrap";

function HomePage() {

    const [jobEmail, setJobEmail] = useState("");
    const [description, setDescription] = useState("");

    /*const options = { 
        method: 'POST',
        url: 'https://linkedin-jobs-search.p.rapidapi.com/',
        headers: {
            'content-type': 'application/json',
            'X-RapidAPI-Host': 'linkedin-jobs-search.p.rapidapi.com',
            'X-RapidAPI-Key': '5244d31626msh133f1dfa08dbf81p1efa3djsn328adc51a7f3'
        },
        data: '{"search_terms":"python programmer","location":"10001","page":"1","fetch_full_text":"yes"}'
    };

    axios.request(options).then(function (response) {
        console.log(response.data);
    }).catch(function (error) {
        console.error(error);
    });*/
  /*
    const options = {
        method: 'POST',
        url: 'https://indeed11.p.rapidapi.com/',
        headers: {
            'content-type': 'application/json',
            'X-RapidAPI-Host': 'indeed11.p.rapidapi.com',
            'X-RapidAPI-Key': '5244d31626msh133f1dfa08dbf81p1efa3djsn328adc51a7f3'
        },
        data: '{"search_terms":"crypto","location":"Atlanta, GA","page":"1","fetch_full_text":"yes"}'
    };*/
    /*
    axios.request(options).then(function (response) {
        console.log(response.data);
    }).catch(function (error) {
        console.error(error);
    });*/

    

    return (
        <div className="Homepage">

            <div className="jobPost">
                <Card className="text-center">
                    <Card.Header>New Suitable</Card.Header>
                    <Card.Body>
                        <Form action="http://localhost:2021/Home/Post" method="POST">

                            <Row className="mb-3">

                                <Form.Group as={Col} controlId="formGridCity">
                                    <Form.Label>City</Form.Label>
                                    <Form.Control name="city" type="text" placeholder="Insert city" />
                                </Form.Group>

                                <Form.Group as={Col} controlId="formGridState">
                                    <Form.Label>Type of work</Form.Label>
                                    <Form.Select name="typeOfWork" defaultValue="Choose...">
                                        <option>Full - Time </option>
                                        <option>Part - Time</option>
                                    </Form.Select>
                                </Form.Group>

                                <Form.Group as={Col} controlId="formGridfield">
                                    <Form.Label>Salary</Form.Label>
                                    <Form.Control name="salary" type="text" placeholder="Offer salary" />
                                </Form.Group>

                                <Form.Group as={Col} controlId="formGridProfession">
                                    <Form.Label>Job Title</Form.Label>
                                    <Form.Control name="jobTitle" type="text" placeholder="enter job Title" />
                                </Form.Group>
                            </Row>

                            <Row className="mb-3">
                                <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                    <Form.Label>Email address</Form.Label>
                                    <Form.Control name="email" onChange={(e) => setJobEmail(e.target.value)} type="email" placeholder={jobEmail || "name@example.com"} />
                                </Form.Group>

                                <Form.Group className="mb-3" controlId="exampleForm.ControlTextarea1">
                                    <Form.Label>Suitable Description</Form.Label>
                                    <Form.Control name="description" onChange={(e) => setDescription(e.target.value)} as="textarea" rows={3} />
                                </Form.Group>

                                <Form.Group className="mb-3" controlId="exampleForm.ControlTextarea1">
                                    <Form.Label>requirements</Form.Label>
                                    <Form.Control name="requierments" as="textarea" rows={3} />
                                </Form.Group>
                            </Row>

                            <Card.Text>

                            </Card.Text>
                            <Button type="submit" variant="primary">Add Post</Button>
                        </Form>
                    </Card.Body>

                    <Card.Footer className="text-muted">The only way to do great work is to love what you do.</Card.Footer>
                </Card>
            </div>

            {/*<div className="JobsPosts">
                <Card border="light" style={{ width: '18rem' }}>
                    <Card.Header>{jobEmail || "Job Desciption"}</Card.Header>
                    <Card.Body>
                        <Card.Title>Light Card Title</Card.Title>
                        <Card.Text>
                            {description || "Some quick example text to build on the card title and make up the bulkof the card's content."}
                        </Card.Text>
                    </Card.Body>
                </Card>
                <br />
    </div>*/}
        </div>
    )
}

export default HomePage;