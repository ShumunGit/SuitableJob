import React, { useState, useRef, useEffect } from "react";
import { Button, Form } from "react-bootstrap";
import { useNavigate } from 'react-router-dom';
import axios from "axios";
import '../App.css';

function LogIn() {
    const url = "http://localhost:2021/Login";

    const [LoginEmail, getEmail] = useState("");
    const [LoginPwd, getPwd] = useState("");

    useEffect(() => {
        const get_LoginEmail = window.localStorage.getItem("loginEmail");
        getEmail(JSON.parse(get_LoginEmail));

        const get_LoginPwd = window.localStorage.getItem("loginPwd");
        getPwd(JSON.parse(get_LoginPwd));

    }, [])

    useEffect(()=>{
        window.localStorage.setItem('loginEmail', JSON.stringify(LoginEmail));
        window.localStorage.setItem('loginPwd', JSON.stringify(LoginPwd));
    })

    useEffect(() =>{
        axios.post(url).then(res => {
            console.log(res.data)
        })
    }, [])
    //let navigate = useNavigate();

    return (

        <div className="LoginForm">
      
           <Form action={url} method="POST">

                <Form.Group className="mb-3" controlId="formBasicEmail">
                    <Form.Label>Email address</Form.Label>
                    <Form.Control onChange={(e) => getEmail(e.target.value)} type="email" name="email" placeholder="Enter email" />
                    <Form.Text className="text-muted">
                        We'll never share your email with anyone else.
                    </Form.Text>
                </Form.Group>

                <Form.Group className="mb-3" controlId="formBasicPassword">
                    <Form.Label>Password</Form.Label>
                    <Form.Control  onChange={(e) => getPwd(e.target.value)} type="password" name="password" placeholder="Password" />
                </Form.Group>
                
                <Form.Group className="mb-3" controlId="formBasicCheckbox">
                    <Form.Check type="checkbox" label="Save Login" />
                </Form.Group>
                <Button variant="primary" type="submit"/*onClick={() => { navigate('/Profile')}}*/>
                    Submit
                </Button>

            </Form>

  
        </div>
    )
}

export default LogIn;