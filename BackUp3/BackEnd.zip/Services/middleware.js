export const sayHello = (res, req, next) => {
    console.log("Say hello");
    req.name = 'Shimon';
    next();
}