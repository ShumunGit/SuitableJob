import { db } from './db_access.js';
import { genreteHash, checkPassword } from './encryption.js';

/*
export const customersLst = () => {
         db.query("SELECT * FROM customers", function (err, rows, fields) {
        if (err) throw err;
        console.log(`Results: ${JSON.stringify(rows)}`);
    })
}
*/
// check if customer exists.
export const getCustomer = async (EmailAddress) => {

    try {
        const [customer] = await db.query(`SELECT * FROM customers WHERE Email='${EmailAddress}'`);
        // console.log(customer);
        if (customer[0]) {
            return customer;
        } else {
            return false;
        }
    } catch (error) {
        console.log(error);
    }
}

// Entities customers. 
export const SetCustomer = async (User_Id, req) => {

    const { Fname, Lname, email, phone, password, cpassword } = req.body;
    const HashedPassword = await genreteHash(password);
    const customer = await getCustomer(email);

    if (!customer[0]) {

        try {
            await db.query(`INSERT INTO customers (Fname, Lname, Email, Phone, Password, Cpassword)
            VALUES ('${Fname}', '${Lname}', '${email}', '${phone}', '${password}', '${HashedPassword}')`);
            console.log("Customer registered");
        } catch (error) {
            console.log(error);
        }
    } else {
        console.log("Customer Exsits");
    }
}

// Entities Log in.  
export const Login = async (req, res) => {

    const { email, password } = req.body;

    const [pwd] = await db.query(`SELECT Cpassword FROM customers WHERE Email='${email}'`)

    if (pwd[0]) {
        const hashedPasswor = pwd[0].Cpassword;
        const verifiedPwd = await checkPassword(password, hashedPasswor);
        //console.log(verifiedPwd);

        return verifiedPwd;
  
    } else {
        //console.log("Email is not exists");

        return false;
    }
}

// Entities contact. 
export const CustomerContact = async (req) => {
    const { fname, lname, email, phone, subject, textarea } = req.body;

    if (true) {
        try {
            await db.query(`INSERT INTO Contact (Fname, Lname, Email, Phone, Subject, TextArea)
            VALUES ('${fname}', '${lname}', '${email}', '${phone}', '${subject}', '${textarea}')`);
            console.log("customer send message");
        } catch (error) {
            console.log(error);
        }
    }

}

// Check if user inserted.
export const getUserId = () => {

    const id = Math.floor(Math.random() * 100000);

    const getUserId = db.query(`SELECT customer_id from User_Profile_Info WHERE customer_id='${id}'`);

    while (id == getUserId[0]) {
        id = Math.floor(Math.random() * 100000)
    }
    //console.log(id)
    return id
}

// Entities Details. 
export const User_Info = async (customer_id, req, res) => {

    // customer profile info. 
    const {
        Fname,
        Lname,
        Phone,
        UserEmail,
        UserTitle,
        country,
        city,
        address,
        about
    } = req.body;

    // customer profile education. 
    const {
        HeighSchoolName,
        HeighSchoolProfession,

        HeighEduName,
        EduProfession,

        OtherEduName,
        OtherProfession
    } = req.body;

    // customer profile experience. 
    const { First_job,
        First_pro,
        First_start,
        First_end,
        Sec_job,
        Sec_pro,
        Sec_start,
        Sec_end,
        Third_job,
        Third_pro,
        Third_start,
        Third_end } = req.body;
    //console.log(req.body)

    const userRegister = await getCustomer(UserEmail);

    const userInfo = await db.query(`SELECT Email FROM User_Profile_Info Where Email='${UserEmail}'`)

    if (userRegister && userInfo[0].length == 0) {
        try {
            // insert into userProfileInfo
            await db.query(`INSERT INTO User_Profile_Info (customer_id, Fname, Lname, Phone, Email, Title, Country, City, Address, About)
            VALUES ('${customer_id}','${userRegister[0].Fname}', '${userRegister[0].Lname}', '${userRegister[0].Phone}', '${userRegister[0].Email}', '${UserTitle}', '${country}','${city}','${address}','${about}')`)
            console.log("user info insetred to profile.")

            // insert into user profile education. 
            await db.query(`INSERT INTO Profile_Education (customer_id, HeighSchool, HeighSchoolPro, HeighEducation, HeighEduPro, OtherEducation, OtherProfession) 
            VALUES ('${customer_id}', '${HeighSchoolName}', '${HeighSchoolProfession}', '${HeighEduName}', '${EduProfession}', '${OtherEduName}', '${OtherProfession}')`)
            console.log("Education inserted.")

            // insert into user profile experince. 
            await db.query(`INSERT INTO Profile_Experience (customer_id, First_Job, First_Profession, Fisrt_Start, Fisrt_End, Sec_Job, Sec_Profession, Sec_Start, Sec_End, Third_Job, Third_Profession, Third_Start, Third_End)
            VALUES ('${customer_id}',
            '${First_job}',
            '${First_pro}',
            '${First_start}',
            '${First_end}',
            '${Sec_job}',
            '${Sec_pro}',
            '${Sec_start}',
            '${Sec_end}', '${Third_job}', '${Third_pro}', '${Third_start}', '${Third_end}')`)
            console.log("experience inserted.")

        } catch (err) {
            console.log(err)
        }
        //console.log(userRegister)
    }/* else if (userExsits[0].length > 0) {
        await db.query(`UPDATE User_Profile_Info SET Fname='${Fname}', Lname='${Lname}', Phone='${Phone}', Email='${UserEmail}',
        Title='${UserTitle}', Country='${country}', City='${city}', Address='${address}', About='${about}' WHERE Email='${UserEmail}'`)
        console.log(Fname, Lname + "is updated is Profile info sucessfuly.")
    }*/

}

// Entitis Education. 
export const User_Education = async (req, res) => {

    const {
        HeighSchoolName,
        HeighSchoolProfession,

        HeighEduName,
        EduProfession,

        OtherEduName,
        OtherProfession
    } = req.body;

    const userId = await db.query(`SELECT customer_id FROM User_Profile_Info WHERE customer_id='${customer_id}'`)

    if (userId[0].length == 0) {
        try {
            await db.query(`INSERT INTO Profile_Education (customer_id, HeighSchool, HeighSchoolPro, HeighEducation, HeighEduPro, OtherEducation, OtherProfession) 
            VALUES ('${customer_id}', '${HeighSchoolName}', '${HeighSchoolProfession}', '${HeighEduName}', '${EduProfession}', '${OtherEduName}', '${OtherProfession}')`)
            console.log("Education inserted.")
        } catch (err) {
            console.log(err)
        }
    } else {
        console.log("Customer Esits!")
    }

}

// Entities Experience. 
export const User_Experience = async (customer_id, req, res) => {

    const { First_job,
        First_pro,
        First_start,
        First_end,
        Sec_job,
        Sec_pro,
        Sec_start,
        Sec_end,
        Third_job,
        Third_pro,
        Third_start,
        Third_end } = req.body;
    //console.log(req.body)
    try {
        await db.query(`INSERT INTO Profile_Experience (customer_id, First_Job, First_Profession, Fisrt_Start, Fisrt_End, Sec_Job, Sec_Profession, Sec_Start, Sec_End, Third_Job, Third_Profession, Third_Start, Third_End)
         VALUES ('${customer_id}',
                 '${First_job}',
                 '${First_pro}',
                 '${First_start}',
                 '${First_end}',
                 '${Sec_job}',
                 '${Sec_pro}',
                 '${Sec_start}',
                 '${Sec_end}', '${Third_job}', '${Third_pro}', '${Third_start}', '${Third_end}')`)
    } catch (err) {
        console.log(err)
    }
}

// Entities jobs post. 
export const InsertPost = async (req, res) => {

    const { city, typeOfWork, salary, jobTitle, email, description, requierments } = req.body;

    try {
        await db.query(`INSERT INTO NewPost (City, TypeOfWork, Salary, JobTitle, email, SuitableDescription, requirements)
        VALUES ('${city}', '${typeOfWork}', '${salary}', '${jobTitle}', '${email}', '${description}', '${requierments}')`);
        console.log("post inserted");
    } catch (err) {
        console.log(err)
    }
}

// send obj to the user Result. 
export const sendData = async (req, res) => {
    const postLst = [];
    try {
        const [post] = await db.query(`SELECT * FROM NewPost`);
        //const Cityname = post[0].City;
        //const mySalary = post[0].Salary;
        for (let i = 0; i < post.length; i++) {
            postLst.push(post[i])
            //console.log(post[i])
        }
        res.json(postLst)
    } catch (err) {
        console.log(err);
    }
}

const userInfo = async () => {
    const email = 'Shon@gmail.com'
    const listInfo = await db.query(`SELECT * FROM User_Profile_Info Where Email='${email}'`)
    console.log(JSON.stringify(listInfo[0]))
}
//userInfo()

/*
const DeletePsot = async() =>{
    try{
        await db.query(`DELETE FROM NewPost WHERE id > 161 AND id < 931`)
    }catch(err){
        console.log(err);
    }
}

DeletePsot()*/

// Entities search job. 

/*
// Log in with email address. 
export const Login = async (req) =>{
    const { email, password } = req.body;
    const hashedPassword = await genreteHash(password);
    const customer  = await getCustomer(email);

    if(customer){
        try {

            await db.query(`INSERT INTO customer_login (userEmail, userPwd)
            VALUES ('${email}', '${hashedPassword}')`);

            const [client] = await db.query(`SELECT * FROM customers WHERE Email='${email}'`);
            //console.log(client[0].Email);
            return customer;
        } catch (error) {
            console.log(error);
        }
    }else{
        console.log('email not exists')
    }
}*/


