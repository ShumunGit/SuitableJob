
import Express from 'express';
import { getCustomer,
         SetCustomer,
         Login,
         CustomerContact,
         InsertPost,
         sendData,
         User_Info,
         getUserId,
         User_Experience,
         User_Education,
          } from './Services/query.js';
import { sayHello } from './Services/middleware.js';
import cors from 'cors';
import axios from 'axios';

const app = Express();
const port = 2021;

app.use(cors())
app.use(Express.urlencoded({ extended: true }));
app.use(Express.json({ extended: true }));

//getCustomer("viva@gmail.com");

app.get('/', sayHello, async (req,res) => {
    console.log(req.name)
    res.send('middleware page');
})

app.post('/CustomerRegister', function (req, res) {
    SetCustomer(req);
    //console.log(req.body);
    res.redirect('http://localhost:3000/Profile')
})

app.post('/Contact', function (req, res) {
    CustomerContact(req);
    //console.log(req.body);
    res.redirect('http://localhost:3000/Profile')
})

app.post('/Login',  function (req, res){
   // console.log(req.body.email);
   // const useEmail = req.body.email;
    //Login(req, res);
    const logged =  Login(req, res);
    //User_Info_Card(useEmail, req, res)
    logged.then(function(result){
        if(result){
            res.redirect('http://localhost:3000/Profile')
        }else{
            res.redirect('http://localhost:3000/Login')
        }
    })
})

app.get('/UserData-Info', function(req, res){
       //const userEmail = req.body.email;
       //console.log(userEmail)
       //User_Info_Card(userEmail, req, res)
})

app.get('/JobsList', function(req,res) {
    sendData(req, res);
    
})

app.post('/Home/Post', function (req, res) {
    //console.log(req.body)
    InsertPost(req, res);
    res.redirect('http://localhost:3000/Home')
})

// insert user profile into the db. 
app.post('/UserDetails', function(req,res) {
    User_Info(getUserId(),req,  res)
    res.redirect('http://localhost:3000/Profile')
})

app.listen(port, () =>
    console.log(`app running on http://localhost:${port}`))