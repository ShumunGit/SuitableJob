import react from 'react'
import '../index.css';
import 'bootstrap/dist/css/bootstrap.css'

function Footer(){
    return(
        <div className='copyright'>
            <p>&copy; By ShimonC 2022</p>
        </div>
    )
}
export default Footer;